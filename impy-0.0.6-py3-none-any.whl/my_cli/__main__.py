from .cli_t  import impy

if __name__ == '__main__':
    impy()
